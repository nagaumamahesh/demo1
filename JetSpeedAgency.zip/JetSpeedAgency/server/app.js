const express = require('express');
const cors = require('cors');
const connectDB = require('./conn');
const Feedback = require('./model');
const Message = require('./messageModel')
const { createMessage } = require('./messageController');

const app = express();
const port = 8000;

connectDB();

app.use(cors());
app.use(express.json());
app.get('/', async (req, res) => {
  try {
    const allFeedbacks = await Feedback.find();
    res.json(allFeedbacks);
  } catch (err) {
    console.error('Failed to retrieve feedbacks:', err);
    res.status(500).json({ error: 'Failed to retrieve feedbacks' });
  }
});
app.post('/:title/:description/:name', async (req, res) => {
  try {
    const { title, description, name } = req.params;
    const newFeedback = new Feedback({ title, description, name });
    await newFeedback.save();
    res.sendStatus(200);
  } catch (err) {
    console.error('Failed to save feedback:', err);
    res.sendStatus(500);
  }
});
app.post('/messages', createMessage);
app.get('/messages',
  async (req, res) => {
    try {
      const allMessages = await Message.find();
      res.json(allMessages);
    } catch (err) {
      console.error('Failed to retrieve feedbacks:', err);
      res.status(500).json({ error: 'Failed to retrieve feedbacks' });
    }
  });
app.listen(port, (err) => {
  if (err) console.error(err);
  else console.log('Server running on port', port);
});
