const mongoose = require('mongoose');
const feedbackSchema = new mongoose.Schema({
  title: String,
  description: String,
  name: String
});
const Feedback = mongoose.model('Feedback', feedbackSchema);
module.exports = Feedback;