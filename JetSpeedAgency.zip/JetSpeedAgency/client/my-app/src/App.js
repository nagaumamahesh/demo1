import './App.css';
import { BrowserRouter, Route, Routes } from 'react-router-dom';
import Home from './pages/Home';
import AboutPage from './pages/AboutPage';
import FeedbackPage from './pages/FeedbackPage';
import ContactPage from './pages/ContactPage';
import FAQPage from './pages/FAQPage';



const App= () => {
  return(
    <BrowserRouter>
    <Routes>
      <Route index element={<Home/>} />
      <Route path='/about' element={<AboutPage/>} />
      <Route path='/contact' element={<ContactPage/>} />
      <Route path='/faq' element={<FAQPage/>} />
      <Route path='/feedback' element={<FeedbackPage/>} />
    </Routes>
    </BrowserRouter>
  );
}
export default App;
