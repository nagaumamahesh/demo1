import { Link } from "react-router-dom";
import '../styles/Footer.css';
export default function Footer() {
    return (
        <>
            <footer>
                <div className="container">
                    <ul>
                        <li><Link to='/contact'>Contact US</Link></li>
                        <li><Link to="/about">About US</Link></li>
                        <li><Link to='/faq'>FAQ</Link></li>
                        <li><Link to="/feedback">Feedback</Link></li>
                    </ul>
                </div>
            </footer>
        </>
    );
}