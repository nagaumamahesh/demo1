import Form from "./Form";
import Header from "./Header";

export default function FeedbackPage(){
    return (<>
    <Header/>
    <br/>
    <Form/>
    </>);
}