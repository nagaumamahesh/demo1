import Footer from "./Footer";
import Header from "./Header";
export default function AboutPage() {
    return (<>
        <Header />
        <br />
        <div className="about-us">
      <div className="container">
        <div className="row">
          <div className="col-md-6">
            <h2>About Us</h2>
            <p>
              Jetspeed Travels is a leading travel agency committed to providing
              excellent travel experiences to our customers. With our extensive
              network of partners and a team of dedicated professionals, we
              offer a wide range of travel services to cater to various travel
              needs.
            </p>
            <p>
              Our mission is to make travel planning and booking hassle-free and
              convenient for our clients. Whether you're looking for a relaxing
              beach getaway, an adventurous trekking expedition, or a cultural
              exploration, we have the expertise and resources to curate the
              perfect travel itinerary for you.
            </p>
          </div>
          <div className="col-md-6">
            <img
              src="https://0901.nccdn.net/4_2/000/000/024/ec9/logo.jpg#RDAMDAID606546"
              alt="About Us"
              className="img-fluid"
            />
          </div>
        </div>
        <div className="row">
          <div className="col-md-12">
            <h2>Our Services</h2>
            <ul>
              <li>Flight bookings to domestic and international destinations</li>
              <li>Hotel reservations for all budgets</li>
              <li>Customized tour packages</li>
              <li>Car rentals and transportation arrangements</li>
              <li>Visa assistance and travel insurance</li>
              <li>Group travel planning</li>
              <li>24/7 customer support</li>
            </ul>
          </div>
        </div>
        <div className="row">
          <div className="col-md-12">
            <h2>Contact Us</h2>
            <p>
              If you have any inquiries or need assistance with your travel
              plans, feel free to get in touch with us. Our friendly and
              knowledgeable team is here to help you.
            </p>
            <p>
              Email: info@jetspeedtravels.com<br />
              Phone: +1-123-456-7890<br />
              Address: 123 Travel Street, Hyderabad.
            </p>
          </div>
        </div>
      </div>
    </div>
    <Footer/>
    </>);
}