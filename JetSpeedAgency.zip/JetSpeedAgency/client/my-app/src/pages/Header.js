import '../styles/Header.css';
import { Link } from 'react-router-dom';
export default function Header() {
    return (
        <>
            <header>
                <img src="images/logo.png" />
                <nav>
                    <div class="container">
                        <ul>
                            <li><Link to='/'>Home</Link></li>
                            <li><Link to='/about'>About US</Link></li>
                            <li><Link to='/contact'>Contact US</Link></li>
                            <li><Link to='/faq'>FAQ</Link></li>
                            <li><Link to='/feedback'>Feedback</Link></li>
                        </ul>
                    </div>
                </nav>
            </header></>
    );
}