import React, {useState} from 'react'
import Header from './Header'
import Footer from './Footer'
import '../styles/Contact.css'
const ContactPage = () => {
  const [name, setName] = useState('');
  const [email, setEmail] = useState('');
  const [message, setMessage] = useState('');
  const handleSubmit = async (event) => {
    event.preventDefault();
    try {
      const response = await fetch('http://localhost:8000/messages', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({ name, email, message }),
      });
      if (response.ok) {
        alert('Message Sent Successfully')
        console.log('Message sent successfully');
        setName('');
        setEmail('');
        setMessage('');
      } else {
        console.error('Failed to send message');
      }
    } catch (err) {
      console.error('Failed to send message:', err);
    }
  };

  return (
    <>
      <Header />
      <br />
      <div className="contact-page">
        <div className="container">
          <div className="row">
            <div className="col-md-6">
              <h2>Contact Us</h2>
              <p>
                If you have any inquiries or need assistance with your travel
                plans, feel free to get in touch with us. Our friendly and
                knowledgeable team is here to help you.
              </p>
              <p>
                Email: info@jetspeedtravels.com
                <br />
                Phone: +1-123-456-7890
                <br />
                Address: 123 Travel Street, City, Country
              </p>
            </div>
            <div className="col-md-6">
              <h2>Send us a message</h2>
              <form className="contact-form" onSubmit={handleSubmit}>
                <div className="form-group">
                  <label htmlFor="name">Name</label>
                  <input
                    type="text"
                    id="name"
                    className="form-control"
                    value={name}
                    onChange={(e) => setName(e.target.value)}
                  />
                </div>
                <div className="form-group">
                  <label htmlFor="email">Email</label>
                  <input
                    type="email"
                    id="email"
                    className="form-control"
                    value={email}
                    onChange={(e) => setEmail(e.target.value)}
                  />
                </div>
                <div className="form-group">
                  <label htmlFor="message">Message</label>
                  <textarea
                    id="message"
                    className="form-control"
                    rows="5"
                    value={message}
                    onChange={(e) => setMessage(e.target.value)}
                  ></textarea>
                </div>
                <button type="submit" className="btn btn-primary">
                  Send Message
                </button>
              </form>
            </div>
          </div>
        </div>
      </div>
      <Footer />
    </>
  );
};
export default ContactPage;
