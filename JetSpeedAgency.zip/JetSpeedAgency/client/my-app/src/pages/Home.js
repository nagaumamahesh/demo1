import Footer from "./Footer";
import Header from "./Header";
import axios from 'axios';
import React, { useEffect, useState } from "react";

export default function Home() {
    const [feedbacks, setFeedbacks] = useState([])
    useEffect(() => {
        axios.get('http://localhost:8000/').then((response) => {
            setFeedbacks(response.data)
            console.log(feedbacks)
        }).catch((err) => {
            alert(err);
        })
    }, [])
    return (
        <>
            <Header />
            <main>
                <div className="container">
                    <h1>Why Travel With Us?</h1>
                    <p>Awarded #1 Travel Agency for Families with Pre-school Kids</p>
                    <p>Accredited with National Travel Agencies Association</p>
                    <p>Awarded Best Tour Agency in 2013, 2014</p>
                    <h1>Photo Galleries</h1>
                    <h2>Malaysia</h2>
                    <img src="images/malaysia.jpg" />
                    <h2>Japan</h2>
                    <img src="images/japan.jpg" />
                    <h2>China</h2>
                    <img src="images/china.jpg" />
                    <h1>What Customers Are Saying</h1>
                    {feedbacks.map(item => {
                        return (
                            (item.id % 2 === 0) ?
                                <div className="customerBox floatLeft" >
                                    <h1>{item.title}</h1>
                                    <p>{item.description}</p>
                                    <h2>{item.name}</h2>
                                </div>
                                :
                                <div className="customerBox floatRight" >
                                    <h1>{item.title}</h1>
                                    <p>{item.description}</p>
                                    <h2>{item.name}</h2>
                                </div>
                        );
                    })
                    }
                    <div className="clearfloat"></div>
                    <h1>Upcoming Tour Dates</h1>
                    <table>
                        <tr><th>Tour Package</th><th>Dates</th><th>Status</th></tr>
                        <tr><td>8 Days 7 Night China Tour</td><td>1 Mar 15 to 8 Mar 15</td><td>Confirmed Departure, No Vacancies Left</td></tr>
                        <tr><td>10 Days 9 Night Africa Tour</td><td>5 Mar 15 to 14 Mar 15</td><td>Confirmed Departure, No Vacancies Left</td></tr>
                        <tr><td>8 Days 7 Night Greece Tour</td><td>15 Mar 15 to 22 Mar 15</td><td>Confirmed Departure, Vacancies Available</td></tr>
                        <tr><td>13 Days 12 Night Korea and Japan Tour</td><td>20 Mar 15 to 1 Apr 15</td><td>Pending</td></tr>
                        <tr><td>5 Days 4 Night Canada Tour</td><td>23 Mar 15 to 27 Mar 15</td><td>Confirmed Departure, Vacancies Available</td></tr>
                    </table>
                </div>
            </main>
            <Footer />
        </>
    );
}