import React from "react";
import Header from "./Header";
import Footer from "./Footer";
import '../styles/FAQ.css';
const FAQPage = () => {
    const faqItems = [
        {
            question: "What types of travel services do you offer?",
            answer: "We offer flight bookings, hotel reservations, customized tour packages, car rentals, visa assistance, travel insurance, group travel planning, and 24/7 customer support."
        },
        {
            question: "How can I book a flight with Jetspeed Travels?",
            answer: "You can book a flight by visiting our website and using our flight booking feature. Simply enter your travel details, choose your preferred flight, and complete the booking process."
        },
        {
            question: "Do you provide travel insurance?",
            answer: "Yes, we offer travel insurance services to ensure that you have the necessary coverage during your trip. Our team can assist you in selecting the right insurance plan for your travel needs."
        },
        {
            question: "Can you help with visa applications?",
            answer: "Absolutely! We provide visa assistance services to help you with the application process. Our experienced team will guide you through the requirements and support you in obtaining the necessary visas for your travel."
        },
        {
            question: "What if I need to make changes to my travel itinerary?",
            answer: "If you need to make changes to your travel itinerary, such as modifying flights or accommodations, please contact our customer support team. They will assist you in making the necessary changes based on availability and the respective terms and conditions."
        }
    ];
    return (
        <>
            <Header />
            <br />
            <div className="faq-page">
                <div className="container">
                    <div className="row">
                        <div className="col-md-12">
                            <h2>Frequently Asked Questions</h2>
                            <div className="faq-accordion">
                                {faqItems.map((item, index) => (
                                    <div className="card" key={index}>
                                        <div className="card-header">
                                            <button className="btn btn-link" data-toggle="collapse" data-target={`#faq${index + 1}`}>
                                                {item.question}
                                            </button>
                                        </div>
                                        <div id={`faq${index + 1}`} className="collapse">
                                            <div className="card-body">
                                                {item.answer}
                                            </div>
                                        </div>
                                    </div>
                                ))}
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <Footer />
        </>
    );
};

export default FAQPage;
